# Aura Launcher for Fire TV

Apple TV-style home screen for Fire TV Stick: big focus-scaling tiles with a glossy sheen,
background that takes on the focused app's colour, favorites row (hold OK), and an
always-on-style ambient mode (drifting dim clock, date, weather, now playing, slow aurora).

Built with Kotlin + Jetpack Compose. Not yet compiled or tested on a device, so expect to fix a small
build error or two on first open.

## Build

1. Install Android Studio (Koala or newer) and open this folder.
2. Let Gradle sync, then **Build > Build Bundle(s) / APK(s) > Build APK(s)** with the
   **release** variant (select it in *Build Variants*). Release is minified and much smoother than debug.
3. APK ends up in `app/build/outputs/apk/release/`.

## Install on the Fire TV Stick

1. Fire TV: *Settings > My Fire TV > Developer Options* > turn on **ADB debugging** and
   **Apps from Unknown Sources**. (If Developer Options is missing: *About* > press OK on the
   device name 7 times.)
2. Note the IP address under *About > Network*.
3. On your computer:
   ```
   adb connect <fire-tv-ip>:5555
   adb install -r app-release.apk
   ```

## Make it your home screen

Fire OS has no "choose default launcher" setting. Options:

- **Launch it manually**: open Aura from *Your Apps*. It works as a normal app. Back does nothing inside Aura, and Home returns to Amazon's launcher unless you replace it (next option).
- **Replace Amazon's launcher (advanced, at your own risk)**:
  ```
  adb shell pm disable-user --user 0 com.amazon.tv.launcher
  ```
  After this, Home opens Aura. Alexa voice features and Amazon's home content stop working
  while it's disabled, and some Fire OS updates may re-enable it.
  **Undo any time:**
  ```
  adb shell pm enable com.amazon.tv.launcher
  ```
- Third-party launcher-switcher apps also exist; behaviour varies by Fire OS version.

## Optional extras

**Now Playing on the ambient screen** needs notification access:
```
adb shell settings get secure enabled_notification_listeners
adb shell settings put secure enabled_notification_listeners "<existing value>:com.aura.launcher/com.aura.launcher.NowPlayingListener"
```
(If the first command prints `null`, use just `com.aura.launcher/com.aura.launcher.NowPlayingListener`.)

**Use the ambient screen as the system screensaver** (may or may not stick on Fire OS):
```
adb shell settings put secure screensaver_components com.aura.launcher/.AuraDream
```
Regardless, Aura starts its own ambient mode after 1 minute idle (`IDLE_MS` in `MainActivity.kt`).

## Controls

- D-pad: move. **OK**: open. **Hold OK**: add/remove from Favorites.
- Any key wakes from ambient mode (that key press is ignored).

## Notes

- Weather uses Open-Meteo and an IP-based location lookup (ipwho.is). No API keys. Shows °C.
- Ambient clock moves every minute to reduce burn-in risk on OLED/plasma TVs.
