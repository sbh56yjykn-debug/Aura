package com.aura.launcher

import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import android.view.WindowManager
import android.content.Intent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private companion object {
        const val IDLE_MS = 60_000L // ambient mode starts after 1 minute without a key press
    }

    @Volatile private var lastInteraction = SystemClock.elapsedRealtime()
    private val ambient = mutableStateOf(false)
    private val refreshTick = mutableIntStateOf(0)
    private var swallowUp = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
            var pinned by remember { mutableStateOf(Prefs.pinned(this@MainActivity)) }
            val weather by rememberWeather()

            // Re-scan installed apps each time we come back to the launcher, but only swap
            // the list when the set of packages actually changed (no flicker).
            val tick = refreshTick.intValue
            LaunchedEffect(tick) {
                val loaded = AppRepository.load(this@MainActivity)
                if (loaded.map { it.pkg } != apps.map { it.pkg }) apps = loaded
            }

            // Idle watcher -> ambient mode
            LaunchedEffect(Unit) {
                while (true) {
                    delay(3000)
                    if (!ambient.value && SystemClock.elapsedRealtime() - lastInteraction > IDLE_MS) {
                        ambient.value = true
                    }
                }
            }

            // Keep the display awake only while ambient is showing
            LaunchedEffect(ambient.value) {
                if (ambient.value) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }

            BackHandler(enabled = true) { /* A launcher never goes "back" */ }

            Box(Modifier.fillMaxSize().background(Color.Black)) {
                HomeScreen(
                    apps = apps,
                    pinned = pinned,
                    weather = weather,
                    onLaunch = { launch(it) },
                    onTogglePin = { pinned = Prefs.togglePin(this@MainActivity, it.pkg) },
                )
                AnimatedVisibility(
                    visible = ambient.value,
                    enter = fadeIn(tween(1200)),
                    exit = fadeOut(tween(300)),
                ) {
                    AmbientScreen()
                }
            }
        }
    }

    private fun launch(app: AppEntry) {
        try {
            startActivity(app.intent)
            @Suppress("DEPRECATION")
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        lastInteraction = SystemClock.elapsedRealtime()
        if (ambient.value && event.action == KeyEvent.ACTION_DOWN) {
            // First key press only wakes the screen; it never triggers an action.
            ambient.value = false
            swallowUp = true
            return true
        }
        if (swallowUp && event.action == KeyEvent.ACTION_UP) {
            swallowUp = false
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onResume() {
        super.onResume()
        lastInteraction = SystemClock.elapsedRealtime()
        refreshTick.intValue++
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home pressed while already on the launcher
        ambient.value = false
        lastInteraction = SystemClock.elapsedRealtime()
    }
}
