package com.aura.launcher

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val palettes = listOf(
    listOf(Color(0xFF0B1B3A), Color(0xFF1E4E8C), Color(0xFF3AA6A0)),
    listOf(Color(0xFF1A0B2E), Color(0xFF6A2C91), Color(0xFFE0607E)),
    listOf(Color(0xFF07201A), Color(0xFF1B7F5C), Color(0xFF9BD36A)),
    listOf(Color(0xFF2A0F0F), Color(0xFFB8452C), Color(0xFFF2A65A)),
    listOf(Color(0xFF0A1024), Color(0xFF3B3FA8), Color(0xFF8E7CF0)),
)

// Where the clock rests (fractions of the screen). It glides to the next spot every
// minute so no pixel stays lit in one place. This protects OLED/plasma from burn-in.
private val slots = listOf(
    0.06f to 0.10f,
    0.50f to 0.14f,
    0.10f to 0.52f,
    0.48f to 0.55f,
    0.28f to 0.32f,
)

/** Always-on style ambient screen: slow aurora, drifting dim clock, weather, now playing. */
@Composable
fun AmbientScreen() {
    val ctx = LocalContext.current
    val time by rememberClock("h:mm")
    val date by rememberClock("EEEE, d MMMM")
    val weather by rememberWeather()
    val track by NowPlaying.track.collectAsState()

    LaunchedEffect(Unit) {
        while (true) {
            NowPlaying.refresh(ctx)
            delay(4000)
        }
    }

    var scene by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(14_000)
            scene = (scene + 1) % palettes.size
        }
    }

    var slot by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            slot = (slot + 1) % slots.size
        }
    }
    val fx = animateFloatAsState(slots[slot].first, tween(6000, easing = EaseInOut), label = "fx")
    val fy = animateFloatAsState(slots[slot].second, tween(6000, easing = EaseInOut), label = "fy")

    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val u = maxWidth / 100

        Crossfade(scene, animationSpec = tween(3500), label = "scene") { Aurora(it) }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.40f)))

        Column(
            Modifier.offset {
                IntOffset(
                    (constraints.maxWidth * fx.value).toInt(),
                    (constraints.maxHeight * fy.value).toInt()
                )
            }
        ) {
            Text(
                time,
                fontSize = (u * 11f).value.sp,
                fontWeight = FontWeight.Thin,
                color = Color.White.copy(alpha = 0.88f),
            )
            Text(
                date,
                fontSize = (u * 2.4f).value.sp,
                fontWeight = FontWeight.Light,
                color = Color.White.copy(alpha = 0.7f),
            )
            weather?.let {
                Text(
                    it.summary,
                    fontSize = (u * 1.9f).value.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.padding(top = u * 0.8f),
                )
            }
            track?.let {
                Text(
                    "♪  " + it.title + (it.artist?.let { a -> "  ·  $a" } ?: ""),
                    fontSize = (u * 1.9f).value.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.padding(top = u * 0.8f),
                )
            }
        }
    }
}

/** Slow drifting colour blobs, a cheap stand-in for aerial footage. Only the draw phase runs. */
@Composable
private fun Aurora(index: Int) {
    val c = palettes[index % palettes.size]
    val p = rememberInfiniteTransition(label = "aurora").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(24_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "p",
    )
    Canvas(Modifier.fillMaxSize()) {
        drawRect(c[0])
        val w = size.width
        val h = size.height
        val pv = p.value

        val c1 = Offset(w * (0.25f + 0.40f * pv), h * (0.35f + 0.15f * pv))
        drawCircle(
            brush = Brush.radialGradient(listOf(c[1].copy(alpha = 0.8f), Color.Transparent), center = c1, radius = w * 0.55f),
            radius = w * 0.55f,
            center = c1,
        )
        val c2 = Offset(w * (0.80f - 0.40f * pv), h * (0.70f - 0.20f * pv))
        drawCircle(
            brush = Brush.radialGradient(listOf(c[2].copy(alpha = 0.6f), Color.Transparent), center = c2, radius = w * 0.45f),
            radius = w * 0.45f,
            center = c2,
        )
    }
}
