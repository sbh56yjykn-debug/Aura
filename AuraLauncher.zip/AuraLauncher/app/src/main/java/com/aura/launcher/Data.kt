package com.aura.launcher

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// ---------- Clock ----------

@Composable
fun rememberClock(pattern: String): State<String> = produceState("", pattern) {
    val fmt = SimpleDateFormat(pattern, Locale.getDefault())
    while (true) {
        val now = Date()
        value = fmt.format(now)
        delay(60_000L - (now.time % 60_000L) + 50L)
    }
}

// ---------- Weather (Open-Meteo, no API key) ----------

data class Weather(val tempC: Int, val code: Int, val city: String) {
    val summary: String
        get() = "$tempC°C · ${describe(code)}" + if (city.isNotBlank()) " · $city" else ""
}

private fun describe(code: Int): String = when (code) {
    0 -> "Clear"
    1, 2 -> "Partly cloudy"
    3 -> "Cloudy"
    45, 48 -> "Fog"
    51, 53, 55, 56, 57 -> "Drizzle"
    61, 63, 65, 66, 67 -> "Rain"
    71, 73, 75, 77 -> "Snow"
    80, 81, 82 -> "Showers"
    95, 96, 99 -> "Thunderstorm"
    else -> "—"
}

object WeatherRepo {
    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    suspend fun fetch(): Weather? = withContext(Dispatchers.IO) {
        try {
            // Approximate location from IP; no location permission needed on TV.
            val loc = JSONObject(httpGet("https://ipwho.is/"))
            if (!loc.optBoolean("success", false)) return@withContext null
            val lat = loc.getDouble("latitude")
            val lon = loc.getDouble("longitude")
            val city = loc.optString("city", "")
            val w = JSONObject(
                httpGet(
                    "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,weather_code"
                )
            ).getJSONObject("current")
            Weather(w.getDouble("temperature_2m").roundToInt(), w.getInt("weather_code"), city)
        } catch (e: Exception) {
            null
        }
    }
}

@Composable
fun rememberWeather(): State<Weather?> = produceState<Weather?>(null) {
    while (true) {
        val w = WeatherRepo.fetch()
        if (w != null) {
            value = w
            delay(30 * 60_000L)
        } else {
            delay(60_000L)
        }
    }
}

// ---------- Now playing ----------

class NowPlayingListener : NotificationListenerService()

data class Track(val title: String, val artist: String?)

object NowPlaying {
    val track = MutableStateFlow<Track?>(null)

    /** Needs notification access for Aura (see README). Silently shows nothing without it. */
    fun refresh(ctx: Context) {
        try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = msm.getActiveSessions(ComponentName(ctx, NowPlayingListener::class.java))
            val playing = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            val md = playing?.metadata
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            track.value = if (title.isNullOrBlank()) {
                null
            } else {
                Track(
                    title,
                    md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                        ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                )
            }
        } catch (e: Exception) {
            track.value = null
        }
    }
}

// ---------- Preferences (pinned favorites) ----------

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("aura", Context.MODE_PRIVATE)

    fun pinned(c: Context): Set<String> = sp(c).getStringSet("pinned", emptySet())!!.toSet()

    fun togglePin(c: Context, pkg: String): Set<String> {
        val set = pinned(c).toMutableSet()
        if (!set.remove(pkg)) set.add(pkg)
        sp(c).edit().putStringSet("pinned", set).apply()
        return set
    }
}
