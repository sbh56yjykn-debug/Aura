package com.aura.launcher

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Night = Color(0xFF05060A)

@Composable
fun HomeScreen(
    apps: List<AppEntry>,
    pinned: Set<String>,
    weather: Weather?,
    onLaunch: (AppEntry) -> Unit,
    onTogglePin: (AppEntry) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var focusedPkg by remember { mutableStateOf<String?>(null) }
    val focused = remember(apps, focusedPkg) { apps.firstOrNull { it.pkg == focusedPkg } }

    // Background colour follows the focused app. Read inside drawBehind so only the
    // draw phase reruns each frame (no recomposition while it animates).
    val tint = animateColorAsState(focused?.tint ?: Color(0xFF1B2540), tween(700), label = "tint")

    val favorites = remember(apps, pinned) { apps.filter { it.pkg in pinned } }
    val others = remember(apps, pinned) { apps.filter { it.pkg !in pinned } }

    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(apps.isNotEmpty()) {
        if (apps.isNotEmpty()) {
            delay(150)
            runCatching { firstFocus.requestFocus() }
        }
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        listOf(tint.value.copy(alpha = 0.6f), Night),
                        endY = size.height * 0.85f
                    )
                )
            }
    ) {
        // "u" = 1% of screen width. Everything scales from it, so the layout looks the
        // same on any Fire TV resolution/density.
        val u: Dp = maxWidth / 100
        val side = u * 5.5f
        val tileW = (maxWidth - u * 10) / 5.4f

        Column(Modifier.fillMaxSize().padding(top = u * 3.5f, bottom = u * 1.5f)) {
            TopBar(u, weather, Modifier.padding(horizontal = side))
            Spacer(Modifier.weight(1f))

            Crossfade(
                targetState = focused?.label ?: "",
                animationSpec = tween(250),
                label = "hero",
                modifier = Modifier.padding(horizontal = side)
            ) { label ->
                Text(
                    label,
                    fontSize = (u * 4.4f).value.sp,
                    fontWeight = FontWeight.Light,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                if (focused != null && focused.pkg in pinned) "Hold OK to remove from Favorites"
                else "Hold OK to add to Favorites",
                fontSize = (u * 1.5f).value.sp,
                color = Color.White.copy(alpha = 0.5f),
                modifier = Modifier.padding(start = side, end = side, top = u * 0.6f),
            )
            Spacer(Modifier.height(u * 1.2f))

            val toggle: (AppEntry) -> Unit = { app ->
                onTogglePin(app)
                scope.launch {
                    delay(250)
                    runCatching { firstFocus.requestFocus() }
                }
            }

            if (favorites.isNotEmpty()) {
                AppRow("Favorites", favorites, tileW, u, side, firstFocus, { focusedPkg = it.pkg }, onLaunch, toggle)
            }
            AppRow(
                "Apps", others, tileW, u, side,
                if (favorites.isEmpty()) firstFocus else null,
                { focusedPkg = it.pkg }, onLaunch, toggle
            )
        }
    }
}

@Composable
private fun TopBar(u: Dp, weather: Weather?, modifier: Modifier) {
    val time by rememberClock("h:mm a")
    val date by rememberClock("EEE, d MMM")
    Row(
        modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            "Aura",
            fontSize = (u * 2.2f).value.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White.copy(alpha = 0.55f),
        )
        Column(horizontalAlignment = Alignment.End) {
            Text(
                time,
                fontSize = (u * 3f).value.sp,
                fontWeight = FontWeight.Light,
                color = Color.White,
            )
            Text(
                date + (weather?.let { "  ·  ${it.summary}" } ?: ""),
                fontSize = (u * 1.5f).value.sp,
                color = Color.White.copy(alpha = 0.6f),
            )
        }
    }
}

@Composable
private fun AppRow(
    title: String,
    items: List<AppEntry>,
    tileW: Dp,
    u: Dp,
    side: Dp,
    firstFocus: FocusRequester?,
    onFocus: (AppEntry) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onPin: (AppEntry) -> Unit,
) {
    Text(
        title,
        fontSize = (u * 1.7f).value.sp,
        fontWeight = FontWeight.Medium,
        color = Color.White.copy(alpha = 0.75f),
        modifier = Modifier.padding(start = side, top = u * 0.8f),
    )
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(u * 1.6f),
        contentPadding = PaddingValues(horizontal = side, vertical = u * 1.8f),
    ) {
        itemsIndexed(items, key = { _, a -> a.pkg }) { index, app ->
            AppTile(
                app = app,
                w = tileW,
                requester = if (index == 0) firstFocus else null,
                labelSize = (u * 1.3f).value,
                onFocus = { onFocus(app) },
                onClick = { onLaunch(app) },
                onLongClick = { onPin(app) },
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppTile(
    app: AppEntry,
    w: Dp,
    requester: FocusRequester?,
    labelSize: Float,
    onFocus: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }

    // Animated State objects are read inside graphicsLayer {} so focus changes only
    // invalidate the layer. No recomposition, which keeps scrolling and focus moves fast.
    val scale = animateFloatAsState(
        if (focused) 1.16f else 1f,
        spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow),
        label = "scale"
    )
    val glow = animateFloatAsState(if (focused) 1f else 0f, tween(260), label = "glow")

    val tileShape = RoundedCornerShape(w * 0.07f)
    val h = w * 9 / 16

    Column(Modifier.width(w)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(h)
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                    translationY = -glow.value * 6.dp.toPx()
                    shadowElevation = glow.value * 48f
                    shape = tileShape
                    clip = true
                }
                .then(if (requester != null) Modifier.focusRequester(requester) else Modifier)
                .onFocusChanged {
                    focused = it.isFocused
                    if (it.isFocused) onFocus()
                }
                .combinedClickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClick,
                    onLongClick = onLongClick,
                )
        ) {
            if (app.isBanner) {
                Image(
                    bitmap = app.image,
                    contentDescription = app.label,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(app.tint.copy(alpha = 0.95f), app.tint.copy(alpha = 0.5f))
                            )
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Image(
                        bitmap = app.image,
                        contentDescription = app.label,
                        modifier = Modifier.fillMaxHeight(0.6f).aspectRatio(1f),
                    )
                }
            }
            // Glossy sheen that fades in on focus (Apple TV style)
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = glow.value }
                    .background(
                        Brush.verticalGradient(
                            0f to Color.White.copy(alpha = 0.26f),
                            0.55f to Color.Transparent,
                        )
                    )
            )
        }

        // Label appears under the tile when focused
        Text(
            app.label,
            fontSize = labelSize.sp,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .padding(top = w * 0.1f)
                .graphicsLayer { alpha = glow.value },
        )
    }
}
